# Controle Financeiro Netlify

Aplicativo completo de gestão financeira pessoal.

## Como Publicar
1. Acesse https://app.netlify.com
2. Arraste esta pasta para a área de deploy